#!/usr/bin/env python3
"""
Week 11 HPC assignment
Project: Climate Governance and ND-GAIN climate-vulnerability prediction
Student: Erick Munala Sifuna

The script reads an ND-GAIN CSV file from the working directory (or downloads
the published archive if no CSV/ZIP is present), trains two regression models,
evaluates them, and saves the best model and run outputs.
"""

import os
import glob
import zipfile
import urllib.request
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

warnings.filterwarnings("ignore", category=FutureWarning)

RANDOM_STATE = 42
DATA_URL = "https://gain.nd.edu/assets/647440/ndgain_countryindex_2026.zip"
DATA_DIR = Path("ndgain_data")
OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def obtain_csv_files():
    """Find local CSVs, extract a local ZIP, or attempt the ND-GAIN download."""
    csv_files = glob.glob(str(DATA_DIR / "**" / "*.csv"), recursive=True)
    csv_files += [p for p in glob.glob("*.csv") if p not in csv_files]

    if csv_files:
        return csv_files

    local_zips = glob.glob("*.zip")
    zip_path = Path(local_zips[0]) if local_zips else Path("ndgain_countryindex_2026.zip")

    if not zip_path.exists():
        print("No local CSV/ZIP found. Attempting to download ND-GAIN data...")
        try:
            urllib.request.urlretrieve(DATA_URL, zip_path)
        except Exception as exc:
            raise FileNotFoundError(
                "ND-GAIN data is not available. Copy the ND-GAIN CSV or ZIP "
                "into this job's working directory and submit the job again. "
                f"Download attempt failed: {exc}"
            )

    DATA_DIR.mkdir(exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as archive:
        archive.extractall(DATA_DIR)

    csv_files = glob.glob(str(DATA_DIR / "**" / "*.csv"), recursive=True)
    if not csv_files:
        raise FileNotFoundError("The archive contained no CSV files.")
    return csv_files


def normalized_name(name):
    return "".join(ch.lower() for ch in str(name) if ch.isalnum())


def find_column(columns, candidates):
    lookup = {normalized_name(col): col for col in columns}
    for candidate in candidates:
        key = normalized_name(candidate)
        if key in lookup:
            return lookup[key]
    for candidate in candidates:
        key = normalized_name(candidate)
        for normalized, original in lookup.items():
            if key and key in normalized:
                return original
    return None


def load_dataset():
    csv_files = obtain_csv_files()
    tables = {}
    for file_path in csv_files:
        try:
            tables[file_path] = pd.read_csv(file_path)
            print(f"Read {file_path}: {tables[file_path].shape}")
        except Exception as exc:
            print(f"Skipping {file_path}: {exc}")

    if not tables:
        raise ValueError("CSV files were found, but none could be read.")

    def table_score(item):
        path, frame = item
        label = (os.path.basename(path) + " " +
                 " ".join(map(str, frame.columns))).lower()
        return (3 * int("vulnerab" in label)
                + 2 * int("readiness" in label)
                + int("country" in label))

    selected_path, frame = max(tables.items(), key=table_score)
    print(f"\nSelected dataset: {selected_path}")
    return frame


def prepare_data(frame):
    target = find_column(
        frame.columns,
        ["Vulnerability", "Vulnerability Score", "Vulnerability Index",
         "Climate Vulnerability"]
    )
    if target is None:
        possible = [col for col in frame.columns if "vulnerab" in str(col).lower()]
        if possible:
            target = possible[0]
    if target is None:
        raise ValueError(
            "Could not identify the vulnerability target column. "
            "Inspect the CSV and edit the target selection in this script."
        )

    readiness = find_column(
        frame.columns, ["Readiness", "Readiness Score", "Readiness Index"]
    )
    numeric_cols = frame.select_dtypes(include=np.number).columns.tolist()
    excluded = [
        "vulnerab", "exposure", "sensitivity", "adaptivecapacity",
        "countrycode", "iso3", "iso", "year", "rank"
    ]

    features = []
    if readiness is not None and readiness != target and readiness in numeric_cols:
        features.append(readiness)

    for col in numeric_cols:
        name = normalized_name(col)
        if col == target or col in features:
            continue
        if any(term in name for term in excluded):
            continue
        features.append(col)

    features = features[:10]
    if not features:
        raise ValueError("No suitable numeric predictor columns were found.")

    data = frame[[target] + features].copy()
    for col in data.columns:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.replace([np.inf, -np.inf], np.nan).dropna(subset=[target])
    features = [col for col in features if data[col].notna().any()]

    if len(data) < 10:
        raise ValueError("Too few usable rows for a meaningful train/test split.")

    X = data[features]
    y = data[target]
    print(f"Target variable: {target}")
    print(f"Predictor variables: {features}")
    print(f"Usable observations: {len(data)}")
    return X, y, target, features


def main():
    print("=" * 65)
    print("WEEK 11 HPC JOB: CLIMATE GOVERNANCE MACHINE LEARNING")
    print("=" * 65)

    frame = load_dataset()
    X, y, target, features = prepare_data(frame)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE
    )
    print(f"Training observations: {len(X_train)}")
    print(f"Testing observations: {len(X_test)}")

    models = {
        "Linear Regression": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", LinearRegression())
        ]),
        "Random Forest": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(
                n_estimators=300,
                random_state=RANDOM_STATE,
                min_samples_leaf=2,
                n_jobs=2
            ))
        ])
    }

    records = []
    for name, model in models.items():
        print(f"\nTraining {name}...")
        model.fit(X_train, y_train)
        for split, x_part, y_part in [
            ("Training", X_train, y_train),
            ("Test", X_test, y_test)
        ]:
            pred = model.predict(x_part)
            records.append({
                "Model": name,
                "Dataset": split,
                "MAE": mean_absolute_error(y_part, pred),
                "RMSE": float(np.sqrt(mean_squared_error(y_part, pred))),
                "R2": r2_score(y_part, pred)
            })

    results = pd.DataFrame(records)
    print("\nPERFORMANCE RESULTS")
    print(results.to_string(index=False, float_format=lambda value: f"{value:.5f}"))
    results.to_csv(OUTPUT_DIR / "model_performance.csv", index=False)

    test_results = results[results["Dataset"] == "Test"]
    best_name = test_results.loc[test_results["RMSE"].idxmin(), "Model"]
    best_model = models[best_name]

    artifact = {
        "model": best_model,
        "model_name": best_name,
        "feature_columns": features,
        "target_name": target,
        "project": "ND-GAIN climate vulnerability regression"
    }
    joblib.dump(artifact, OUTPUT_DIR / "climate_governance_best_model.joblib")

    # Demonstrate reloading and prediction using one held-out observation.
    reloaded = joblib.load(OUTPUT_DIR / "climate_governance_best_model.joblib")
    example = X_test.iloc[[0]]
    predicted = reloaded["model"].predict(example)[0]
    print(f"\nBest model by test RMSE: {best_name}")
    print(f"Example predicted climate-vulnerability score: {predicted:.6f}")
    print(f"Outputs saved in: {OUTPUT_DIR.resolve()}")
    print("JOB COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    main()
