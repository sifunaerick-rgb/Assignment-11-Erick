#!/bin/bash
#SBATCH --job-name=climate_ml
#SBATCH --output=climate_ml_%j.out
#SBATCH --error=climate_ml_%j.err
#SBATCH --time=00:30:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=4G

# Week 11 HPC batch job for the climate-governance ML project.
# Check your institution's HPC documentation for the correct Python module.
# If the cluster requires a partition, add its exact directive here after
# checking the KENET/HPC session instructions. Do not use a guessed partition.

set -e

echo "Job started: $(date)"
echo "Running on host: $(hostname)"
echo "Working directory: $(pwd)"

# Option A: activate a virtual environment created in your home/project folder.
# Create it once on the login node:
#   python3 -m venv ~/venvs/climate-ml
#   source ~/venvs/climate-ml/bin/activate
#   pip install -r requirements.txt
#
# Then uncomment the next line and edit the path if necessary:
# source ~/venvs/climate-ml/bin/activate

# Option B: use the Python module provided by your HPC centre.
# Inspect available modules with: module avail python
# Then uncomment and edit the appropriate module name:
# module load python/3.x

python --version
python climate_governance_hpc.py

echo "Job finished: $(date)"
