# Week 11 Assignment — Running a Machine Learning Job on HPC

**Student:** Erick Munala Sifuna  
**Project:** Using Machine Learning to Support Climate Governance and Adaptation Decision-Making  
**Dataset:** ND-GAIN Country Index  
**Models:** Linear Regression and Random Forest Regression

## 1. Files in this folder

- `climate_governance_hpc.py` — Python program that loads ND-GAIN data, prepares the target and predictors, trains two regression models, evaluates them, and saves the best model.
- `climate_governance_job.slurm` — Slurm batch script that requests computing resources and runs the Python program.
- `requirements.txt` — Python packages needed by the program.
- `README.md` — this guide and assignment explanation.

## 2. Accessing the HPC environment

The exact login address, account name, authentication method, module names, and scheduler configuration are provided by the institution/KENET HPC training session. They cannot be inferred from the assignment screenshot.

From a terminal, connect using the command supplied by the HPC administrator, commonly:

```bash
ssh YOUR_USERNAME@HPC_LOGIN_ADDRESS
```

Do not publish your password, private key, access token, or login address in a public GitHub repository.

## 3. Set up the working environment

Create a project directory and move the assignment files into it:

```bash
mkdir -p ~/week11_climate_governance
cd ~/week11_climate_governance
```

Create and activate a Python virtual environment:

```bash
python3 -m venv ~/venvs/climate-ml
source ~/venvs/climate-ml/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If virtual environments are not supported on the cluster, follow the KENET/HPC session instructions for loading Python and packages with the module system or approved environment manager.

## 4. Provide the ND-GAIN dataset

Place the ND-GAIN CSV file or ZIP archive in the same directory as `climate_governance_hpc.py`. The program also attempts to download the published archive if no local CSV/ZIP is found and the compute environment has internet access.

For reliable HPC execution, it is preferable to download the data on the login/transfer node (if permitted) and copy the CSV or ZIP into the project directory before submitting the job. Do not assume compute nodes have unrestricted internet access.

The script searches for a vulnerability target column and selects eligible numeric predictors. It prints the selected file, target, predictors, and number of observations. Inspect these before interpreting results.

## 5. Submit the job to the scheduler

Ensure the virtual environment activation line in `climate_governance_job.slurm` is uncommented and points to the environment you created. If the HPC centre requires a partition or a particular module, edit the batch file according to the session instructions.

Submit:

```bash
sbatch climate_governance_job.slurm
```

The scheduler returns a job ID, for example:

```text
Submitted batch job 123456
```

The number above is only an illustration. Use the actual job ID returned by your scheduler.

## 6. Check job status and retrieve output

Check the queue:

```bash
squeue -u "$USER"
```

Check a particular job (where supported):

```bash
scontrol show job JOB_ID
```

After it finishes, inspect the output and error logs:

```bash
cat climate_ml_JOB_ID.out
cat climate_ml_JOB_ID.err
```

Replace `JOB_ID` with the actual numeric job ID. The `.out` file should contain the performance table and the message `JOB COMPLETED SUCCESSFULLY` if the run succeeds.

The program writes these result files into `outputs/`:

- `model_performance.csv`
- `climate_governance_best_model.joblib`

Retrieve or copy the output files to your local machine using the transfer method taught in the HPC session (for example, `scp` or the centre's transfer service).

## 7. Computing resources requested

The batch script requests:

| Resource | Request | Reason |
|---|---:|---|
| Nodes | 1 | This project is a single-node task and does not need distributed computing. |
| Tasks | 1 | One Python process runs the analysis. |
| CPUs per task | 2 | The Random Forest can use two worker threads; two CPUs are sufficient for this moderate tabular dataset. |
| Memory | 4 GB | Enough as an initial allocation for a moderate country-indicator table, preprocessing, and model fitting. |
| Wall time | 30 minutes | A reasonable initial time limit for downloading/reading data and fitting the two models. |

These are starting allocations, not measured peak resource usage. If the job is killed for exceeding memory or time, inspect the scheduler's accounting information and adjust resources based on actual usage. The cluster may impose its own maximums or require a partition/account directive.

## 8. Why HPC differs from Colab or a personal computer

- **HPC:** Jobs are submitted to a scheduler. The scheduler places them on available compute nodes according to requested CPUs, memory, time, and cluster policy. Jobs may wait in a queue. Output is normally written to log files.
- **Google Colab:** Code is commonly run interactively in a hosted notebook session. Runtime availability and limits are controlled by the Colab service, and a session can disconnect.
- **Personal computer:** Code runs directly on the machine's available CPU and memory. There is usually no batch scheduler or shared queue, but resources are limited to that computer.

HPC is useful for larger datasets, repeated experiments, or computationally intensive models because it provides managed access to shared compute resources. This Week 11 example is deliberately modest and uses HPC to demonstrate the batch-job workflow rather than to claim that the model requires a supercomputer.

## 9. Evidence of successful execution

The assignment asks for evidence such as job output or screenshots. This evidence must come from your actual KENET/HPC account after submitting the job. It cannot be truthfully generated in advance.

After a successful run, include:
1. Screenshot or copied terminal output showing the `sbatch` command and the job ID.
2. Screenshot/output showing the job status or that it has left the queue.
3. The contents of `climate_ml_JOB_ID.out` showing the metrics and `JOB COMPLETED SUCCESSFULLY`.
4. The generated `outputs/model_performance.csv` file.

Do not submit an invented job ID or fabricated execution screenshot.

## 10. Limitations

The program depends on the ND-GAIN data release and the actual CSV column names. The script attempts to identify the vulnerability target automatically, but the selected target and predictors must be checked. A successful run does not by itself prove that the model is scientifically valid. Country-level data can hide local differences, and the random train/test split may be optimistic if repeated years for a country occur in both sets. Use time-based or country-grouped validation for stronger research conclusions.

## 11. GitHub submission

Upload the Python script, Slurm job file, requirements file, README, and (if permitted by the dataset's terms) the relevant output CSV. Avoid uploading credentials, private keys, or restricted raw data. Add the actual job output and screenshots as execution evidence after you have run the job.
